-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 06, 2021 at 04:51 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `email`, `password`) VALUES
(1, 'sunnygkp10@gmail.com', '123456'),
(2, 'admin@admin.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

CREATE TABLE `answer` (
  `qid` text NOT NULL,
  `ansid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `answer`
--

INSERT INTO `answer` (`qid`, `ansid`) VALUES
('558923538f48d', '558923539a46c'),
('55892353f05c4', '55892354051be'),
('5fec49980cd06', '5fec499840f70'),
('5fec499889fa1', '5fec49988dad0'),
('5fec74166d942', '5fec74167f3f7'),
('5fec7416e3360', '5fec7416ef185'),
('5fec741741d35', '5fec74174a88c'),
('5fec741770bf5', '5fec741779691'),
('5fec7417bc8ef', '5fec7417cb12a'),
('5fec741822ccf', '5fec74182b83a'),
('5fec741860688', '5fec7418692f6'),
('5fec741897872', '5fec7418a0312'),
('5fec7418d4a08', '5fec7418e60dc'),
('5fec74192048a', '5fec741931be5'),
('5fec77bce401e', '5fec77bcf39ec'),
('5fec77bd367be', '5fec77bd41ec2'),
('5fec77bd7e64d', '5fec77bd871e4'),
('5fec77bdc6f33', '5fec77bde4066'),
('5fec77be3592b', '5fec77be445e6'),
('5fec77be7e335', '5fec77be897e6'),
('5fec77bebaa03', '5fec77bec3601'),
('5fec77bf11806', '5fec77bf33dc6'),
('5fec77bf738d6', '5fec77bf7f15d'),
('5fec77bfb599c', '5fec77bfc11fb'),
('5fec81ab6cc35', '5fec81ab7cf8f'),
('5fec81abddb98', '5fec81abef338'),
('5fec81ac464a0', '5fec81ac51c89'),
('5fec81ac85847', '5fec81ac90f8b'),
('5fec81ad1799b', '5fec81ad31c41'),
('5fec83a7d6fa1', '5fec83a7d711e'),
('5fec85878ef0d', '5fec85878f0be'),
('5fec86e30ea5d', '5fec86e31ba58'),
('5fec86e35bed4', '5fec86e373733'),
('5fec86e3c4d74', '5fec86e3d036a'),
('5fec86e423f2a', '5fec86e42f6ce'),
('5fec86e463341', '5fec86e46e9a3');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` text NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `subject` varchar(500) NOT NULL,
  `feedback` varchar(500) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `email`, `subject`, `feedback`, `date`, `time`) VALUES
('5fcf5a8ed3d3f', 'batista', 'batista123@mail.com', 'update the questions', 'kjbfkbsjhsdvklhsjvfbvbsfnvshvsjbvsnvjhzdfvhdsfhhshviudfhoahdfivusfvfigdffiuv', '2020-12-08', '11:50:54am'),
('5fd077609926b', 'srsrg', 'ouhvuihsrv@jbddhf.com', 'srgsrgrs', 'alkenhfioaeae', '2020-12-09', '08:06:08am');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `email` varchar(50) NOT NULL,
  `eid` text NOT NULL,
  `score` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `sahi` int(11) NOT NULL,
  `wrong` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`email`, `eid`, `score`, `level`, `sahi`, `wrong`, `date`) VALUES
('himanshu@mail.com', '5fec71b89ecbd', 10, 10, 10, 0, '2020-12-30 14:39:24');

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `qid` varchar(50) NOT NULL,
  `option` varchar(5000) NOT NULL,
  `optionid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`qid`, `option`, `optionid`) VALUES
('558923538f48d', '255.0.0.0', '558923539a46c'),
('558923538f48d', '255.255.255.0', '558923539a480'),
('558923538f48d', '255.255.0.0', '558923539a48b'),
('558923538f48d', 'none of these', '558923539a495'),
('55892353f05c4', '192.168.1.100', '5589235405192'),
('55892353f05c4', '172.168.16.2', '55892354051a3'),
('55892353f05c4', '10.0.0.0.1', '55892354051b4'),
('55892353f05c4', '11.11.11.11', '55892354051be'),
('5fec49980cd06', 'Man Mohan Singh', '5fec499840f62'),
('5fec49980cd06', 'Narendra Modi', '5fec499840f70'),
('5fec49980cd06', 'Pratibha patil', '5fec499840f72'),
('5fec49980cd06', 'Donald Trump', '5fec499840f74'),
('5fec499889fa1', '1938', '5fec49988dac2'),
('5fec499889fa1', '1945', '5fec49988dacc'),
('5fec499889fa1', '1950', '5fec49988dace'),
('5fec499889fa1', '1947', '5fec49988dad0'),
('5fec74166d942', 'HighText Machine Language', '5fec74167f3f0'),
('5fec74166d942', 'HyperText and links Markup Language', '5fec74167f3f6'),
('5fec74166d942', 'HyperText Markup Language', '5fec74167f3f7'),
('5fec74166d942', 'None of these', '5fec74167f3f8'),
('5fec7416e3360', 'Head, Title, HTML, body', '5fec7416ef17d'),
('5fec7416e3360', 'HTML, Body, Title, Head', '5fec7416ef183'),
('5fec7416e3360', 'HTML, Head, Body, Title', '5fec7416ef184'),
('5fec7416e3360', 'HTML, Head, Title, Body', '5fec7416ef185'),
('5fec741741d35', '.ht', '5fec74174a885'),
('5fec741741d35', '.html', '5fec74174a88c'),
('5fec741741d35', '.hml', '5fec74174a88d'),
('5fec741741d35', 'None of the above', '5fec74174a88e'),
('5fec741770bf5', 'Web browser', '5fec741779691'),
('5fec741770bf5', 'Server', '5fec741779697'),
('5fec741770bf5', 'Interpreter', '5fec741779698'),
('5fec741770bf5', 'None of the above', '5fec741779699'),
('5fec7417bc8ef', 'case-sensitive', '5fec7417cb122'),
('5fec7417bc8ef', 'in upper case', '5fec7417cb129'),
('5fec7417bc8ef', 'not case sensitive', '5fec7417cb12a'),
('5fec7417bc8ef', 'in lowercase', '5fec7417cb12b'),
('5fec741822ccf', 'class', '5fec74182b835'),
('5fec741822ccf', 'id', '5fec74182b83a'),
('5fec741822ccf', 'type', '5fec74182b83b'),
('5fec741822ccf', 'None of the above', '5fec74182b83c'),
('5fec741860688', 'disc, square, triangle', '5fec7418692f0'),
('5fec741860688', 'polygon, triangle, circle', '5fec7418692f5'),
('5fec741860688', 'disc, circle, square', '5fec7418692f6'),
('5fec741860688', 'All of the above', '5fec7418692f7'),
('5fec741897872', 'style', '5fec7418a0312'),
('5fec741897872', 'type', '5fec7418a0317'),
('5fec741897872', 'class', '5fec7418a0318'),
('5fec741897872', 'None of the above', '5fec7418a0319'),
('5fec7418d4a08', 'Title', '5fec7418e60d4'),
('5fec7418d4a08', 'Style', '5fec7418e60db'),
('5fec7418d4a08', 'Both (a) & (b)', '5fec7418e60dc'),
('5fec7418d4a08', 'None of the above', '5fec7418e60dd'),
('5fec74192048a', '1990', '5fec741931be5'),
('5fec74192048a', '1980', '5fec741931bea'),
('5fec74192048a', '2000', '5fec741931beb'),
('5fec74192048a', '1995', '5fec741931bec'),
('5fec77bce401e', 'Hypertex Processor', '5fec77bcf39da'),
('5fec77bce401e', 'Personal Home Page', '5fec77bcf39e7'),
('5fec77bce401e', 'Hyper Markup Preprocessor', '5fec77bcf39ea'),
('5fec77bce401e', 'Hypertext Preprocessor', '5fec77bcf39ec'),
('5fec77bd367be', 'Server-side', '5fec77bd41ec2'),
('5fec77bd367be', 'Client-side', '5fec77bd41ed0'),
('5fec77bd367be', 'Browser-side', '5fec77bd41ed3'),
('5fec77bd367be', 'In-side', '5fec77bd41edd'),
('5fec77bd7e64d', 'Rasmus Lerdorf', '5fec77bd871e4'),
('5fec77bd7e64d', 'Willam Makepiece', '5fec77bd871e9'),
('5fec77bd7e64d', 'Drek Kolkevi', '5fec77bd871eb'),
('5fec77bd7e64d', 'List Barely', '5fec77bd871ec'),
('5fec77bdc6f33', 'PHP can be used to develop web applications.', '5fec77bde405b'),
('5fec77bdc6f33', 'PHP makes a website dynamic', '5fec77bde4063'),
('5fec77bdc6f33', 'PHP applications can not be compile', '5fec77bde4064'),
('5fec77bdc6f33', 'PHP can not be embedded into html.', '5fec77bde4066'),
('5fec77be3592b', 'Get', '5fec77be445e6'),
('5fec77be3592b', 'Post', '5fec77be445f5'),
('5fec77be3592b', 'Both', '5fec77be445f9'),
('5fec77be3592b', 'None', '5fec77be445fc'),
('5fec77be7e335', '1993', '5fec77be897dc'),
('5fec77be7e335', '1994', '5fec77be897e6'),
('5fec77be7e335', '1995', '5fec77be897e8'),
('5fec77be7e335', '1996', '5fec77be897e9'),
('5fec77bebaa03', '.html', '5fec77bec35eb'),
('5fec77bebaa03', '.xml', '5fec77bec35fd'),
('5fec77bebaa03', '.php', '5fec77bec3601'),
('5fec77bebaa03', '.hphp', '5fec77bec3606'),
('5fec77bf11806', 'JavaScript', '5fec77bf33daf'),
('5fec77bf11806', 'HTML', '5fec77bf33dbf'),
('5fec77bf11806', 'CSS', '5fec77bf33dc2'),
('5fec77bf11806', 'All of the above', '5fec77bf33dc6'),
('5fec77bf738d6', 'VBScript', '5fec77bf7f14e'),
('5fec77bf738d6', 'JavaScript', '5fec77bf7f15a'),
('5fec77bf738d6', 'Perl and C', '5fec77bf7f15d'),
('5fec77bf738d6', 'All of the above', '5fec77bf7f15e'),
('5fec77bfb599c', 'True', '5fec77bfc11fb'),
('5fec77bfb599c', 'False', '5fec77bfc1209'),
('5fec77bfb599c', 'PHP can only create, open and close files on the server', '5fec77bfc120b'),
('5fec77bfb599c', 'PHP can read, write and delete files on the server', '5fec77bfc120d'),
('5fec81ab6cc35', 'Object-Oriented', '5fec81ab7cf87'),
('5fec81ab6cc35', 'Object-Based', '5fec81ab7cf8f'),
('5fec81ab6cc35', 'Assembly-language', '5fec81ab7cf90'),
('5fec81ab6cc35', 'High-level', '5fec81ab7cf92'),
('5fec81abddb98', 'Alternative to if-else', '5fec81abef323'),
('5fec81abddb98', 'Switch statement', '5fec81abef332'),
('5fec81abddb98', 'If-then-else statement', '5fec81abef335'),
('5fec81abddb98', 'immediate if', '5fec81abef338'),
('5fec81ac464a0', 'Conditional block', '5fec81ac51c7b'),
('5fec81ac464a0', 'block that combines a number of statements into a single compound statement', '5fec81ac51c89'),
('5fec81ac464a0', 'both conditional block and a single statement', '5fec81ac51c8c'),
('5fec81ac464a0', 'block that contains a single statement', '5fec81ac51c8e'),
('5fec81ac85847', 'Shows a warning', '5fec81ac90f73'),
('5fec81ac85847', 'Prompts to complete the statement', '5fec81ac90f80'),
('5fec81ac85847', 'Throws an error', '5fec81ac90f85'),
('5fec81ac85847', 'Ignores the statements', '5fec81ac90f8b'),
('5fec81ad1799b', 'Preprocessor', '5fec81ad31c37'),
('5fec81ad1799b', 'Triggering Event', '5fec81ad31c3e'),
('5fec81ad1799b', 'RMI', '5fec81ad31c40'),
('5fec81ad1799b', 'Function/Method', '5fec81ad31c41'),
('5fec83a7d6fa1', 'spacing', '5fec83a7d7116'),
('5fec83a7d6fa1', 'margin', '5fec83a7d711c'),
('5fec83a7d6fa1', 'padding', '5fec83a7d711e'),
('5fec83a7d6fa1', 'inner-margin', '5fec83a7d7120'),
('5fec85878ef0d', 'margin', '5fec85878f0b3'),
('5fec85878ef0d', 'clear', '5fec85878f0bc'),
('5fec85878ef0d', 'float', '5fec85878f0be'),
('5fec85878ef0d', 'padding', '5fec85878f0c1'),
('5fec86e30ea5d', 'CSS is used to control the style of a web document in a simple and easy way.', '5fec86e31ba4e'),
('5fec86e30ea5d', 'CSS is the acronym for \"Cascading Style Sheet\".', '5fec86e31ba55'),
('5fec86e30ea5d', 'You can write CSS once and then reuse same sheet in multiple HTML pages.', '5fec86e31ba57'),
('5fec86e30ea5d', 'All of the above.', '5fec86e31ba58'),
('5fec86e35bed4', 'border-color', '5fec86e373725'),
('5fec86e35bed4', 'border-decoration', '5fec86e373730'),
('5fec86e35bed4', 'border-style', '5fec86e373733'),
('5fec86e35bed4', 'border-line', '5fec86e373735'),
('5fec86e3c4d74', 'empty-cell', '5fec86e3d036a'),
('5fec86e3c4d74', 'blank-cell', '5fec86e3d0378'),
('5fec86e3c4d74', 'noncontent-cell', '5fec86e3d037b'),
('5fec86e3c4d74', 'void-cell', '5fec86e3d037e'),
('5fec86e423f2a', 'border-top-color', '5fec86e42f6bb'),
('5fec86e423f2a', 'border-left-color', '5fec86e42f6ca'),
('5fec86e423f2a', 'border-right-color', '5fec86e42f6ce'),
('5fec86e423f2a', 'border-bottom-color', '5fec86e42f6d1'),
('5fec86e463341', 'font-style', '5fec86e46e992'),
('5fec86e463341', 'test-size', '5fec86e46e9a1'),
('5fec86e463341', 'font-size', '5fec86e46e9a3'),
('5fec86e463341', 'text-style', '5fec86e46e9a5');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `eid` text NOT NULL,
  `qid` text NOT NULL,
  `qns` text NOT NULL,
  `choice` int(10) NOT NULL,
  `sn` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`eid`, `qid`, `qns`, `choice`, `sn`) VALUES
('558922ec03021', '558923538f48d', 'what is correct mask for A class IP???', 4, 1),
('558922ec03021', '55892353f05c4', 'which is not a private IP??', 4, 2),
('5fec48f4e0d57', '5fec49980cd06', 'Who is the current Prime Minister of India', 4, 1),
('5fec71b89ecbd', '5fec74166d942', 'HTML stands for -', 4, 1),
('5fec71b89ecbd', '5fec7416e3360', 'The correct sequence of HTML tags for starting a webpage is -', 4, 2),
('5fec71b89ecbd', '5fec741741d35', 'An HTML program is saved by using the ____ extension.', 4, 3),
('5fec71b89ecbd', '5fec741770bf5', ' A program in HTML can be rendered and read by -', 4, 4),
('5fec71b89ecbd', '5fec7417bc8ef', 'The tags in HTML are -', 4, 5),
('5fec71b89ecbd', '5fec741822ccf', 'Which of the following attribute is used to provide a unique name to an element?', 4, 6),
('5fec71b89ecbd', '5fec741860688', 'What are the types of unordered or bulleted list in HTML?', 4, 7),
('5fec71b89ecbd', '5fec741897872', 'Which of the following HTML attribute is used to define inline styles?', 4, 8),
('5fec71b89ecbd', '5fec7418d4a08', 'Which of the following are the attributes of the HTML Elements?', 4, 9),
('5fec71b89ecbd', '5fec74192048a', 'The year in which HTML was first proposed _______.', 4, 10),
('5fec7538d49e1', '5fec77bce401e', 'PHP Stands for?', 4, 1),
('5fec7538d49e1', '5fec77bd367be', 'PHP is an example of ___________ scripting language.', 4, 2),
('5fec7538d49e1', '5fec77bd7e64d', 'Who is known as the father of PHP?', 4, 3),
('5fec7538d49e1', '5fec77bdc6f33', 'Which of the following is not true?', 4, 4),
('5fec7538d49e1', '5fec77be3592b', 'Which of the following method sends input to a script via a URL?', 4, 5),
('5fec7538d49e1', '5fec77be7e335', 'In which year PHP was created?', 4, 6),
('5fec7538d49e1', '5fec77bebaa03', 'PHP files have a default file extension of_______.', 4, 7),
('5fec7538d49e1', '5fec77bf11806', 'PHP files can contain ________ code.', 4, 8),
('5fec7538d49e1', '5fec77bf738d6', 'The PHP syntax is most similar to:', 4, 9),
('5fec7538d49e1', '5fec77bfb599c', 'PHP can create, open, read, write, delete, and close files on the server.', 4, 10),
('5fec80d4f043b', '5fec81ab6cc35', 'Which type of JavaScript language is ___', 4, 1),
('5fec80d4f043b', '5fec81abddb98', 'Which one of the following also known as Conditional Expression:', 4, 2),
('5fec80d4f043b', '5fec81ac464a0', 'In JavaScript, what is a block of statement?', 4, 3),
('5fec80d4f043b', '5fec81ac85847', 'When interpreter encounters an empty statements, what it will do:', 4, 4),
('5fec80d4f043b', '5fec81ad1799b', 'Which one of the following is the correct way for calling the JavaScript code?', 4, 5),
('5fec85ec2fea0', '5fec86e30ea5d', 'Which of the following is correct about CSS?', 4, 1),
('5fec85ec2fea0', '5fec86e35bed4', 'If we want to use a nice looking green dotted border around an image, which css property will we use?', 4, 2),
('5fec85ec2fea0', '5fec86e3c4d74', 'Which of the following properties will we use to display border around a cell without any content ?', 4, 3),
('5fec85ec2fea0', '5fec86e423f2a', 'Which of the following property changes the color of right border?', 4, 4),
('5fec85ec2fea0', '5fec86e463341', 'Which CSS property is used to control the text size of an element ?', 4, 5);

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

CREATE TABLE `quiz` (
  `eid` text NOT NULL,
  `title` varchar(100) NOT NULL,
  `sahi` int(11) NOT NULL,
  `wrong` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `time` bigint(20) NOT NULL,
  `intro` text NOT NULL,
  `tag` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `quiz`
--

INSERT INTO `quiz` (`eid`, `title`, `sahi`, `wrong`, `total`, `time`, `intro`, `tag`, `date`) VALUES
('558922ec03021', 'Networking', 2, 1, 2, 5, '', 'networking', '2015-06-23 09:12:12'),
('5fec48f4e0d57', 'General Knowledge', 1, 1, 2, 3, 'Test your General Knowledge ', '#GK', '2020-12-30 09:31:32'),
('5fec71b89ecbd', 'Html Coding', 1, 0, 10, 10, 'You will be answering ten questions based on HTML. Each question carries 1 mark and there is no negative marking.', '#HTML', '2020-12-30 12:25:28'),
('5fec7538d49e1', 'Php Coding', 1, 0, 10, 10, 'You will be answering teh questions based on PHP. Each question carries 1 mark and there is no negative marking.', '#PHP', '2020-12-30 12:40:24'),
('5fec80d4f043b', 'Javascript Coding', 1, 0, 5, 5, '', '#JS', '2020-12-30 13:29:56'),
('5fec85ec2fea0', 'Css Coding', 1, 0, 5, 5, '', '#CSSC', '2020-12-30 13:51:40');

-- --------------------------------------------------------

--
-- Table structure for table `rank`
--

CREATE TABLE `rank` (
  `email` varchar(50) NOT NULL,
  `score` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rank`
--

INSERT INTO `rank` (`email`, `score`, `time`) VALUES
('avantika420@gmail.com', 8, '2015-06-23 14:49:39'),
('nik1@gmail.com', 1, '2015-06-23 16:11:50'),
('himanshu@mail.com', 10, '2020-12-30 14:39:24');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `name` varchar(50) NOT NULL,
  `gender` varchar(5) NOT NULL,
  `college` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mob` bigint(20) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `gender`, `college`, `email`, `mob`, `password`) VALUES
('Avantika', 'F', 'KNIT sultanpur', 'avantika420@gmail.com', 7785068889, 'e10adc3949ba59abbe56e057f20f883e'),
('Himanshu Bai', 'M', 'BTL Institute of Technology', 'himanshu@mail.com', 1234567890, 'e10adc3949ba59abbe56e057f20f883e'),
('Nikunj', 'M', 'XYZ', 'nik1@gmail.com', 987, '202cb962ac59075b964b07152d234b70');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
